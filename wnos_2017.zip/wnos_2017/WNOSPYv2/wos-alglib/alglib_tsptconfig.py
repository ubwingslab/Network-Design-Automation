# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

objective = '-__ssrate___00*inst10_lbd - __ssrate___00*inst13_lbd - __ssrate___00*inst15_lbd - __ssrate___00*inst16_lbd - __ssrate___00*inst18_lbd - __ssrate___00*inst19_lbd - __ssrate___00*inst20_lbd - __ssrate___00*inst3_lbd - __ssrate___00*inst6_lbd - __ssrate___00*inst7_lbd - __ssrate___00*inst9_lbd + log(__ssrate___00)'
optvar = '__ssrate___00'
